import socket
from threading import *
import time

host = "localhost"
port = 3128

server = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

server.bind((host, port))

print("SERVIDOR INICIADO")

while True:

    arq = open("arq01.txt", "w")

    arq.write("Servidor iniciado em: ")
    arq.write(host)
    arq.write("Hora")
    arq.write(time.ctime())

    msgs, endCliente = server.recvfrom(2048)

    msg = msgs.decode("utf-8").upper()

    server.sendto(msg.encode("utf-8"), endCliente)

    print("Hora: ", time.ctime()," : ",msg)