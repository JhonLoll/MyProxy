import socket
from threading import *
import time

ip = "0.0.0.0"
host = 12000

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    s.bind((ip, host))

    s.listen(5)

    print("Iniciado em %s %s" %(ip, host))

    (data, cliente) = s.accept()

    print("Conectado por: %s" %cliente[0])

    while True:

        message = data.recvfrom(2048)

        msgs = message.decode("utf-8").upper()

        s.sendto(msgs.encode("utf-8"),("", ))

except Exception as erro:
    print(erro)
    s.close()