#importacoes
from datetime import datetime
import socket
#data
data = datetime.now()
#criando proxys
proxys = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
proxys.bind(("localhost",3128))
proxys.listen(2)
while True:
    print("prontinho...")
    cliente, ipcliente = proxys.accept()
    mensagem = cliente.recv(1024)
    msg = mensagem.decode()
    ##########
    serve = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    serve.connect(("192.168.28.1", 3129))
    serve.send(msg.encode())
    #####
    mensagemres = serve.recv(1024)
    cliente.send(bytes(mensagemres))
    if mensagem == "sair":
        proxys.close()
        break
