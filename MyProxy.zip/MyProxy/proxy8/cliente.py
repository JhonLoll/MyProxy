import socket
cliente = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
cliente.connect(("localhost", 3128))

while True:
    mensagem = input("digite uma mensagem: ")
    cliente.send(mensagem.encode())
    mensagem = cliente.recv(1024)
    msg = mensagem.decode()
    print(msg)
    
cliente.close()