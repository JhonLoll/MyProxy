#importacoes
import socket
from datetime import datetime
#data
data = datetime.now()
#criando servidor
servidor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = "192.168.28.1"
port = 3129
servidor.bind((host, port))
servidor.listen(2)
while True:
    print("pronto...")
    cliente, ipcliente = servidor.accept()
    mensagem = cliente.recv(1024)
    msg = mensagem.decode()
    print(ipcliente, "ip do cliente")
    print(msg)
    #enviando mensagem para proxys
    cliente.send(bytes(msg, 'utf-8'))

    if mensagem == "sair":
        servidor.close()
        break